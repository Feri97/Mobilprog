package com.example.mobilprog;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;

public class CarsActivity extends AppCompatActivity {

    private SqliteDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cars);
        RecyclerView carView = findViewById(R.id.myCarList);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        carView.setLayoutManager(linearLayoutManager);
        carView.setHasFixedSize(true);
        mDatabase = new SqliteDatabase(this);
        ArrayList<Car> allCars = mDatabase.listCars();

        if (allCars.size() > 0) {
            carView.setVisibility(View.VISIBLE);
            CarAdapter mAdapter = new CarAdapter(this, allCars);
            carView.setAdapter(mAdapter);
        }
        else {
            carView.setVisibility(View.GONE);
            Toast.makeText(this, "There is no car in the database.", Toast.LENGTH_LONG).show();
        }

        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addTaskDialog();
            }
        });
    }


    private void addTaskDialog() {

        LayoutInflater inflater = LayoutInflater.from(this);
        View subView = inflater.inflate(R.layout.add_car, null);
        final EditText manufacturerField = subView.findViewById(R.id.enterManufacturer);
        final EditText modelField = subView.findViewById(R.id.enterModel);
        final EditText descriptionField = subView.findViewById(R.id.enterDescription);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add new car");
        builder.setView(subView);
        builder.create();

        builder.setPositiveButton("ADD", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String manufacturer = manufacturerField.getText().toString();
                final String model = modelField.getText().toString();
                final String description = descriptionField.getText().toString();
                if (TextUtils.isEmpty(manufacturer)) {
                    Toast.makeText(CarsActivity.this, "Something went wrong. Check your input values", Toast.LENGTH_LONG).show();
                }
                else {
                    Car newCar = new Car(manufacturer, model, description);
                    mDatabase.addCar(newCar);
                    finish();
                    startActivity(getIntent());
                }
            }
        });

        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(CarsActivity.this, "Task cancelled", Toast.LENGTH_LONG).show();
            }
        });

        builder.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mDatabase != null) {
            mDatabase.close();
        }
    }
}