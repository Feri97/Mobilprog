package com.example.mobilprog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

public class DetailsActivity extends AppCompatActivity {

    private SqliteDatabase mDatabase;
    private int mId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        mDatabase = new SqliteDatabase(this);
        mId = getIntent().getIntExtra("EXTRA_ID", 0);
        Car car = mDatabase.getCar(mId);

        this.getSupportFragmentManager().beginTransaction().replace(R.id.detailsContainer,
                DetailsFragment.newInstance(car.getId(), car.getManufacturer(), car.getModel(), car.getDescription())).addToBackStack(null).commit();

    }
}