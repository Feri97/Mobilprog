package com.example.mobilprog;

import java.io.Serializable;

public class Car {
    private int id;
    private String manufacturer;
    private String model;
    private String description;
    Car(String manufacturer, String model, String description) {
        this.manufacturer = manufacturer;
        this.model = model;
        this.description = description;
    }
    Car(int id, String manufacturer, String model, String description) {
        this.id = id;
        this.manufacturer = manufacturer;
        this.model = model;
        this.description = description;
    }
    Car(int id, String manufacturer, String model) {
        this.id = id;
        this.manufacturer = manufacturer;
        this.model = model;
    }
    int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getManufacturer() {
        return manufacturer;
    }
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}