package com.example.mobilprog;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.IOException;

import static android.app.Activity.RESULT_OK;

public class DetailsFragment extends Fragment {

    private static final String ARG_ID = "id";
    private static final String ARG_MANUFACTURER = "manufacturer";
    private static final String ARG_MODEL = "model";
    private static final String ARG_DESC = "description";
    static final int REQUEST_IMAGE_CAPTURE = 1;

    ImageView imageView;
    SqliteDatabase db;
    private int mId = 1;
    private ImageView iv_image;
    private TextView tv_manufacturer;
    private TextView tv_model;
    private TextView tv_description;
    private String mManufacturer;
    private String mModel;
    private String mDescription;
    private Button btn_img;

    private DetailsActivity da = (DetailsActivity) this.getContext();

    public DetailsFragment() {
        // Required empty public constructor
    }
    public DetailsFragment(int id) {
        this.mId = id;
    }

    public static DetailsFragment newInstance(int id, String manufacturer, String model, String description) {
        DetailsFragment fragment = new DetailsFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_ID, id);
        args.putString(ARG_MANUFACTURER, manufacturer);
        args.putString(ARG_MODEL, model);
        args.putString(ARG_DESC, description);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mId = getArguments().getInt(ARG_ID);
            mManufacturer = getArguments().getString(ARG_MANUFACTURER);
            mModel = getArguments().getString(ARG_MODEL);
            mDescription = getArguments().getString(ARG_DESC);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_details, container, false);

        db = new SqliteDatabase(this.getContext());

        btn_img = view.findViewById(R.id.btn_img);
        btn_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent();
            }
        });
        iv_image = view.findViewById(R.id.imageView);
        iv_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv_image.setScaleType(ImageView.ScaleType.FIT_XY);
            }
        });
        iv_image.setImageBitmap(db.getImage((DetailsActivity) this.getContext(), mId));
        tv_manufacturer = view.findViewById(R.id.textManufacturer);
        tv_manufacturer.setText(mManufacturer);
        tv_model = view.findViewById(R.id.textModel);
        tv_model.setText(mModel);
        tv_description = view.findViewById(R.id.textDescription);
        tv_description.setText(mDescription);
        return view;
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(da,e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");

            try{
                db.saveImage((DetailsActivity) this.getContext(), mId, imageBitmap);
            }catch (IOException e){
                Toast.makeText(da,e.getMessage(), Toast.LENGTH_LONG).show();
            }
            iv_image.setImageBitmap(imageBitmap);
        }
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        ((DetailsActivity) this.getContext()).finish();
    }

}