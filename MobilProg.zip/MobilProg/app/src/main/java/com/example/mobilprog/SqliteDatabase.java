package com.example.mobilprog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.ArrayList;

public class SqliteDatabase extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 5;
    private static final String DATABASE_NAME = "Cars";
    private static final String TABLE_CARS = "Cars";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_MANUFACTURER = "carManufacturer";
    private static final String COLUMN_MODEL = "carModel";
    private static final String COLUMN_DESC = "carDescription";
    private static final String COLUMN_IMAGE = "carImage";

    SqliteDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CARS_TABLE = "CREATE TABLE "
                + TABLE_CARS + "(" + COLUMN_ID
                + " INTEGER PRIMARY KEY,"
                + COLUMN_MANUFACTURER + " TEXT,"
                + COLUMN_MODEL + " TEXT,"
                + COLUMN_DESC + " TEXT,"
                + COLUMN_IMAGE + " Blob"+")";
        db.execSQL(CREATE_CARS_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CARS);
        onCreate(db);
    }

    ArrayList<Car> listCars() {
        String sql = "select * from " + TABLE_CARS;
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Car> storeCars = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                int id = Integer.parseInt(cursor.getString(0));
                String manufacturer = cursor.getString(1);
                String model = cursor.getString(2);
                storeCars.add(new Car(id, manufacturer, model));
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return storeCars;
    }

    public Car getCar(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Car car = null;
        Cursor cursor = db.rawQuery( "select * from "+ TABLE_CARS +" WHERE " + COLUMN_ID+" = " + id, null );

        try {
            if (cursor.moveToFirst()) {
                int dbid = Integer.parseInt(cursor.getString(0));
                String manufacturer = cursor.getString(1);
                String model = cursor.getString(2);
                String description = cursor.getString(3);
                car = new Car(dbid, manufacturer, model, description);
            }
        } finally {
            cursor.close();
        }
        return car;
    }

    void addCar(Car car) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_MANUFACTURER, car.getManufacturer());
        values.put(COLUMN_MODEL, car.getModel());
        values.put(COLUMN_DESC, car.getDescription());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_CARS, null, values);
    }
    void updateCar(Car car) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_MANUFACTURER, car.getManufacturer());
        values.put(COLUMN_MODEL, car.getModel());
        values.put(COLUMN_DESC, car.getDescription());
        SQLiteDatabase db = this.getWritableDatabase();
        db.update(TABLE_CARS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(car.getId())});
    }
    void deleteCar(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CARS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void saveImage(DetailsActivity da, int id, Bitmap bmp) throws IOException {
        SQLiteDatabase db = this.getWritableDatabase();
        byte[] image = getBytesFromBitmap(bmp);

        ContentValues values = new ContentValues();
        values.put(COLUMN_IMAGE, image);
        db.update(TABLE_CARS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});

        Toast.makeText(da, "Done", Toast.LENGTH_LONG).show();
    }

    public byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }
    public Bitmap getImage(DetailsActivity da, int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery( "select " + COLUMN_IMAGE +" from "+ TABLE_CARS +" WHERE " + COLUMN_ID+" = " + id, null );
        Bitmap bmp;
        if(c.moveToNext() && c.getBlob(0) != null)
        {
            byte[] image = c.getBlob(0);
            bmp = BitmapFactory.decodeByteArray(image, 0 , image.length);
            Toast.makeText(da,"Done", Toast.LENGTH_SHORT).show();
            return bmp;
        }else{
            return null;
        }
    }
}