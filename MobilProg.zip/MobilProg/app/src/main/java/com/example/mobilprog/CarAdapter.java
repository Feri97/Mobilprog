package com.example.mobilprog;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Objects;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

class CarAdapter extends RecyclerView.Adapter<CarViewHolder> implements Filterable {

    private Context context;
    private ArrayList<Car> listCars;
    private ArrayList<Car> mArrayList;
    private SqliteDatabase mDatabase;

    CarAdapter(Context context, ArrayList<Car> listCars) {
        this.context = context;
        this.listCars = listCars;
        this.mArrayList = listCars;
        mDatabase = new SqliteDatabase(context);
    }

    @Override
    public CarViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.car_list_layout, parent, false);
        return new CarViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CarViewHolder holder, int position) {
        final Car cars = listCars.get(position);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DetailsActivity.class);
                intent.putExtra("EXTRA_ID", cars.getId());
                context.startActivity(intent);

            }
        });
        holder.tvManufacturer.setText(cars.getManufacturer());
        holder.tvModel.setText(cars.getModel());
        holder.editCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTaskDialog(cars);
            }
        });
        holder.deleteCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabase.deleteCar(cars.getId());
                ((Activity) context).finish();
                context.startActivity(((Activity) context).getIntent());
            }
        });
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    listCars = mArrayList;
                }
                else {
                    ArrayList<Car> filteredList = new ArrayList<>();
                    for (Car car : mArrayList) {
                        if (car.getManufacturer().toLowerCase().contains(charString)) {
                            filteredList.add(car);
                        }
                    }
                    listCars = filteredList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = listCars;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                listCars = (ArrayList<Car>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @Override
    public int getItemCount() {
        return listCars.size();
    }

    private void editTaskDialog(final Car car) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View subView = inflater.inflate(R.layout.add_car, null);
        final EditText manufacturerField = subView.findViewById(R.id.enterManufacturer);
        final EditText modelField = subView.findViewById(R.id.enterModel);
        final EditText descriptionField = subView.findViewById(R.id.enterDescription);
        if (car != null) {
            manufacturerField.setText(car.getManufacturer());
            modelField.setText(car.getModel());
            descriptionField.setText(car.getDescription());
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit car");
        builder.setView(subView);
        builder.create();

        builder.setPositiveButton("EDIT CAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String manufacturer = manufacturerField.getText().toString();
                final String model = modelField.getText().toString();
                final String description = descriptionField.getText().toString();
                if (TextUtils.isEmpty(manufacturer)) {
                    Toast.makeText(context, "Something went wrong. Check your input values", Toast.LENGTH_LONG).show();
                } else {
                    mDatabase.updateCar(new
                            Car(Objects.requireNonNull(car).getId(), manufacturer, model, description));
                    ((Activity) context).finish();
                    context.startActivity(((Activity)
                            context).getIntent());
                }
            }
        });

        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(context, "Task cancelled",Toast.LENGTH_LONG).show();
            }
        });

        builder.show();
    }
}