package com.example.mobilprog;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

class CarViewHolder extends RecyclerView.ViewHolder {
    TextView tvManufacturer, tvModel;
    RelativeLayout car;
    ImageView deleteCar;
    ImageView editCar;
    CarViewHolder(View itemView) {
        super(itemView);
        car = itemView.findViewById(R.id.car);
        tvManufacturer = itemView.findViewById(R.id.carManufacturer);
        tvModel = itemView.findViewById(R.id.model);
        deleteCar = itemView.findViewById(R.id.deleteCar);
        editCar = itemView.findViewById(R.id.editCar);
    }

}